import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPEN_API_KEY"))

CHAT_MODEL = "gpt-4.1-mini"


def ask_llm(system_prompt: str, user_prompt: str) -> str:

    resp = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.2,
    )
    return resp.choices[0].message.content

