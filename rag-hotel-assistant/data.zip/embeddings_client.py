import os
from openai import OpenAI



client = OpenAI(api_key=os.getenv("OPEN_AI_KEY"))

EMBEDDING_MODEL = "text-embedding-3-small"

def embed_text(text: str) -> list[float]:

    if not text:
        return []
    text = text.replace("\n", " ")
    resp = client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=[text]
    )
    return resp.data[0].embedding

