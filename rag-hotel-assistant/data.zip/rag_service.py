# rag_service.py
from typing import List, Tuple

from qdrant_client import QdrantClient

from embeddings_client import embed_text
from llm_client import ask_llm

COLLECTION_NAME = "dynasty_hotel_docs"

SYSTEM_PROMPT = (
    "You are an AI assistant for Dynasty Hotel in Yerevan. "
    "Answer ONLY using the hotel information provided in the CONTEXT. "
    "If the answer is not in the context, say: "
    "\"I’m not sure based on the current hotel information.\""
)


def retrieve_relevant_chunks(query: str, top_k: int = 5) -> List[dict]:
    client = QdrantClient(host="localhost", port=6333)

    query_vector = embed_text(query)

    search_result = client.search(
        collection_name=COLLECTION_NAME,
        query_vector=query_vector,
        limit=top_k,
    )

    chunks: List[dict] = []
    for point in search_result:
        payload = point.payload
        chunks.append(
            {
                "text": payload.get("text", ""),
                "source_file": payload.get("source_file", ""),
                "score": point.score,
            }
        )
    return chunks


def build_context(chunks: List[dict]) -> str:

    parts = []
    for i, c in enumerate(chunks, start=1):
        parts.append(
            f"[{i}] (score={c['score']:.3f}, source={c['source_file']})\n{c['text']}"
        )
    return "\n\n".join(parts)


def answer_question(question: str) -> Tuple[str, List[dict]]:

    chunks = retrieve_relevant_chunks(question, top_k=5)
    context = build_context(chunks)

    user_prompt = f"User question:\n{question}\n\nCONTEXT:\n{context}"
    answer = ask_llm(SYSTEM_PROMPT, user_prompt)
    return answer, chunks

