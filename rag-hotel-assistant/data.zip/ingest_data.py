import uuid
from pathlib import Path

from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels

from embeddings_client import embed_text

DATA_FILE = Path("dynasty_hotel_dataset.md")
COLLECTION_NAME = "dynasty_hotel_docs"
EMBEDDING_SIZE = 1536 


def split_markdown(text: str) -> list[str]:
    chunks = []
    current = []
    for line in text.splitlines():
        if line.strip() == "":
            if current:
                chunk = "\n".join(current).strip()
                if len(chunk) > 20:
                    chunks.append(chunk)
                current = []
        else:
            current.append(line)
    if current:
        chunk = "\n".join(current).strip()
        if len(chunk) > 20:
            chunks.append(chunk)
    return chunks


def main():
    client = QdrantClient(host="localhost", port=6333)

    collections = client.get_collections().collections
    if COLLECTION_NAME not in [c.name for c in collections]:
        client.create_collection(
            collection_name=COLLECTION_NAME,
            vectors_config=qmodels.VectorParams(
                size=EMBEDDING_SIZE,
                distance=qmodels.Distance.COSINE,
            ),
        )
        print(f"Collection '{COLLECTION_NAME}' created")
    else:
        print(f"Collection '{COLLECTION_NAME}' already exists")

    text = DATA_FILE.read_text(encoding="utf-8")
    chunks = split_markdown(text)
    print(f"Total chunks: {len(chunks)}")

    points = []

    for chunk in chunks:
        embedding = embed_text(chunk)
        point_id = str(uuid.uuid4())
        points.append(
            qmodels.PointStruct(
                id=point_id,
                vector=embedding,
                payload={
                    "text": chunk,
                    "source_file": DATA_FILE.name,
                    "language": "en",
                },
            )
        )

    # upsert в Qdrant
    client.upsert(
        collection_name=COLLECTION_NAME,
        points=points,
    )
    print(f"Uploaded {len(points)} points to '{COLLECTION_NAME}'")


if __name__ == "__main__":
    main()

