import streamlit as st

from rag_service import answer_question

st.set_page_config(page_title="Dynasty Hotel AI Concierge", page_icon="🏨")

st.title("Dynasty Hotel AI Concierge 🏨")
st.write("Ask any question about the hotel: SPA, rooms, services, policies, location.")

question = st.text_input(
    "Your question",
    placeholder="Example: Is SPA access included in my stay?",
)

if st.button("Ask the Concierge") and question.strip():
    with st.spinner("Thinking..."):
        answer, chunks = answer_question(question.strip())

    st.subheader("Answer")
    st.write(answer)

    with st.expander("Show retrieved context"):
        for i, c in enumerate(chunks, start=1):
            st.markdown(
                f"**Chunk {i} (score={c['score']:.3f}, source={c['source_file']})**"
            )
            st.write(c["text"])
            st.markdown("---")

