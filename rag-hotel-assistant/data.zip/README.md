# Dynasty Hotel RAG-based AI Assistant

This project is a RAG-based AI system for Dynasty Hotel in Yerevan.

The assistant answers questions about:
- SPA and wellness
- room amenities and facilities
- services included in the stay
- food and dining
- hotel policies and payments
- location and nearby attractions
- contacts and transport

## Project Structure

- `data/dynasty_hotel_dataset.md` — hotel knowledge base (source data)
- `docker-compose.yml` — local Qdrant vector database
- `ingest_data.py` — loads dataset into Qdrant with embeddings
- `embeddings_client.py` — embeddings generator
- `llm_client.py` — LLM client (OpenAI)
- `rag_service.py` — RAG pipeline (retrieve + generate)
- `app.py` — simple Streamlit UI
- `requirements.txt` — dependencies

## How to Run

1. Start Qdrant:
```bash
docker-compose up -d

