## Products & Services

### Balcony Availability
Almost all room categories include a balcony, but availability depends on room type and booking date.

### SPA Zone
The SPA zone includes:
- Finnish sauna
- Turkish hammam
- Jacuzzi
- Walking Kneipp path
- Indoor heated pool

### SPA Rules
- Outside these hours: available only with private booking for an additional fee
- Private SPA booking: 24/7
- Minimum booking time: 2 hours
- Maximum capacity: 8 persons
- Price: 19,000 AMD/hour (includes slippers & towels)
- Reservation required at reception
- Swimsuits required

### Conference Hall
A fully equipped conference hall suitable for business events, seminars, and trainings. Available for an additional fee.

### Cribs & Extra Beds
- Based on availability

### Luggage & Storage
- Luggage storage available upon request

### Included in the Stay
- Welcome drink
- Lunch or dinner
- Children's toys
- Conference hall access
- Breakfast for two
- SPA access (11:00–20:00)
- Parking
- Laundry services
- 10% restaurant discount
- Airport transfer
- Tour organization assistance

# Room Amenities

### Media & Entertainment
- Smart TV
- In-room telephone
- High-speed Wi-Fi

### Electronics & Climate
- Air conditioning
- Climate control system
- Hairdryer
- Lighting fixtures
- Electronic key card locks
- Security system
- Mini-fridge
- USB ports

### Bathroom
- Shower
- Hygienic shower
- Bathrobes
- Shower cabin
- Toiletries
- Slippers
- Private bathroom
- Soap
- Toilet
- Shower cap

### Beds
- King-size bed

### Furniture
- Mirror
- Chair
- Sofa
- Work desk
- Table
- Hangers
- Wardrobe

### Other Amenities
- In-room safe
- Heating
- Drinking water
- Electric kettle
- Carpeted floor
- Tea set
- Non-smoking room
- Toys as a gift for children

### Kitchen & Family Facilities
- High chair for children
- Electric kettle
- Refrigerator

### Massage Services
- Not available

# Food & Dining

### Breakfast
- Included in room rate

### Menu Options
- European cuisine only

### Room Service
Available.

### Restaurant
Available on site.

# Cleaning & Laundry
- Daily housekeeping
- Ironing service
- Laundry (extra charge)
- Dry cleaning (extra charge)

# Nearby Cafes & Bars
- Station Café — 800 m
- Coffee House Mergelyan — 1 km
- Club 11 — 3 km

# Nearby Attractions
- Lovers’ Park — 2.4 km
- Hovhannes Tumanyan Museum — 2.9 km
- Cascade Complex — 3 km
- Matenadaran — 3.4 km
- Armenian Genocide Museum — 3.6 km
- Sergey Parajanov Museum — 3.7 km
- National History Museum — 4 km
- Republic Square — 4 km
- Yerevan Brandy Factory — 5 km
- Erebuni — 10 km

# Views
- Mountain view
- City/Window view

# Outdoor Areas
- Terrace
- Garden

# Safety & Security
- Fire extinguishers
- Smoke detectors
- CCTV outside
- CCTV in common areas
- Security alarm
- Electronic key card access
- 24/7 security staff
- In-room safe

# Transportation

## Airport Transfer
- Available upon request (paid)

## Public Transport
- Metro Druzhba — 1.1 km
- Metro Marshal Baghramyan — 2.1 km
- Train Almast — 5 km
- Train Kanaker — 6 km

## Car Rental
- Available upon request

## Taxi
- Easily accessible

# Policies

## Payment Currency
- All payments must be made in Armenian drams (AMD)

## Deposit
- No deposit required

## Prepayment
- No prepayment required; payment upon arrival

## Long Stay Discounts
- No fixed discounts; special conditions discussed with Sales Department

## Loyalty Program
- No loyalty program; returning guests may receive personal discounts

# Awards & Certifications
- Best Family SPA Hotel in Yerevan 2024

# Contact Information

## Website for Self-Booking
https://dynastyerevan.com/

## Reception Phones
+37433802204
+37410333310

## Sales Manager (Karen)
+37433802205

## Email
info@dynastyerevan.com
